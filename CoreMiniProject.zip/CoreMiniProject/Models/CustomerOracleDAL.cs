﻿//namespace CoreMiniProject.Models
//{
//    public class CustomerOracleDAL : ICustomerDAL
//    {
//    }
//}
